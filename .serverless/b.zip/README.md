# serverless-graphql
Messing around with AWS Lambda and Graphql
